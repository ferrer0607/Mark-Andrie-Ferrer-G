﻿namespace ClassmatesRPG
{
    partial class BattleForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblPlayer1 = new System.Windows.Forms.Label();
            this.txtPlayer1Name = new System.Windows.Forms.TextBox();
            this.cboPlayer1Class = new System.Windows.Forms.ComboBox();
            this.lblPlayer2 = new System.Windows.Forms.Label();
            this.txtPlayer2Name = new System.Windows.Forms.TextBox();
            this.cboPlayer2Class = new System.Windows.Forms.ComboBox();
            this.btnStartBattle = new System.Windows.Forms.Button();
            this.txtBattleLog = new System.Windows.Forms.TextBox();
            this.lblHealth1 = new System.Windows.Forms.Label();
            this.lblHealth2 = new System.Windows.Forms.Label();
            this.picPlayer1 = new System.Windows.Forms.PictureBox();
            this.picPlayer2 = new System.Windows.Forms.PictureBox();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayer1
            // 
            this.lblPlayer1.AutoSize = true;
            this.lblPlayer1.Location = new System.Drawing.Point(30, 60);
            this.lblPlayer1.Name = "lblPlayer1";
            this.lblPlayer1.Size = new System.Drawing.Size(48, 13);
            this.lblPlayer1.TabIndex = 0;
            this.lblPlayer1.Text = "Player 1:";
            // 
            // txtPlayer1Name
            // 
            this.txtPlayer1Name.Location = new System.Drawing.Point(30, 80);
            this.txtPlayer1Name.Name = "txtPlayer1Name";
            this.txtPlayer1Name.Size = new System.Drawing.Size(120, 20);
            this.txtPlayer1Name.TabIndex = 1;
            // 
            // cboPlayer1Class
            // 
            this.cboPlayer1Class.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlayer1Class.FormattingEnabled = true;
            this.cboPlayer1Class.Items.AddRange(new object[] {
            "QuizMaster Quincy",
            "Debugger Dana",
            "CodeCrusher Carlos"});
            this.cboPlayer1Class.Location = new System.Drawing.Point(30, 110);
            this.cboPlayer1Class.Name = "cboPlayer1Class";
            this.cboPlayer1Class.Size = new System.Drawing.Size(120, 21);
            this.cboPlayer1Class.TabIndex = 2;
            // 
            // lblPlayer2
            // 
            this.lblPlayer2.AutoSize = true;
            this.lblPlayer2.Location = new System.Drawing.Point(250, 60);
            this.lblPlayer2.Name = "lblPlayer2";
            this.lblPlayer2.Size = new System.Drawing.Size(48, 13);
            this.lblPlayer2.TabIndex = 3;
            this.lblPlayer2.Text = "Player 2:";
            // 
            // txtPlayer2Name
            // 
            this.txtPlayer2Name.Location = new System.Drawing.Point(250, 80);
            this.txtPlayer2Name.Name = "txtPlayer2Name";
            this.txtPlayer2Name.Size = new System.Drawing.Size(120, 20);
            this.txtPlayer2Name.TabIndex = 4;
            // 
            // cboPlayer2Class
            // 
            this.cboPlayer2Class.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPlayer2Class.FormattingEnabled = true;
            this.cboPlayer2Class.Items.AddRange(new object[] {
            "QuizMaster Quincy",
            "Debugger Dana",
            "CodeCrusher Carlos"});
            this.cboPlayer2Class.Location = new System.Drawing.Point(250, 110);
            this.cboPlayer2Class.Name = "cboPlayer2Class";
            this.cboPlayer2Class.Size = new System.Drawing.Size(120, 21);
            this.cboPlayer2Class.TabIndex = 5;
            // 
            // btnStartBattle
            // 
            this.btnStartBattle.BackColor = System.Drawing.Color.DarkRed;
            this.btnStartBattle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnStartBattle.ForeColor = System.Drawing.Color.White;
            this.btnStartBattle.Location = new System.Drawing.Point(150, 150);
            this.btnStartBattle.Name = "btnStartBattle";
            this.btnStartBattle.Size = new System.Drawing.Size(100, 40);
            this.btnStartBattle.TabIndex = 6;
            this.btnStartBattle.Text = "START BATTLE!";
            this.btnStartBattle.UseVisualStyleBackColor = false;
            this.btnStartBattle.Click += new System.EventHandler(this.btnStartBattle_Click);
            // 
            // txtBattleLog
            // 
            this.txtBattleLog.Location = new System.Drawing.Point(30, 220);
            this.txtBattleLog.Multiline = true;
            this.txtBattleLog.Name = "txtBattleLog";
            this.txtBattleLog.ReadOnly = true;
            this.txtBattleLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBattleLog.Size = new System.Drawing.Size(340, 150);
            this.txtBattleLog.TabIndex = 7;
            // 
            // lblHealth1
            // 
            this.lblHealth1.AutoSize = true;
            this.lblHealth1.Location = new System.Drawing.Point(30, 140);
            this.lblHealth1.Name = "lblHealth1";
            this.lblHealth1.Size = new System.Drawing.Size(70, 13);
            this.lblHealth1.TabIndex = 8;
            this.lblHealth1.Text = "Health: 100%";
            // 
            // lblHealth2
            // 
            this.lblHealth2.AutoSize = true;
            this.lblHealth2.Location = new System.Drawing.Point(250, 140);
            this.lblHealth2.Name = "lblHealth2";
            this.lblHealth2.Size = new System.Drawing.Size(70, 13);
            this.lblHealth2.TabIndex = 9;
            this.lblHealth2.Text = "Health: 100%";
            // 
            // picPlayer1
            // 
            this.picPlayer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPlayer1.Location = new System.Drawing.Point(160, 60);
            this.picPlayer1.Name = "picPlayer1";
            this.picPlayer1.Size = new System.Drawing.Size(80, 80);
            this.picPlayer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPlayer1.TabIndex = 10;
            this.picPlayer1.TabStop = false;
            // 
            // picPlayer2
            // 
            this.picPlayer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPlayer2.Location = new System.Drawing.Point(160, 60);
            this.picPlayer2.Name = "picPlayer2";
            this.picPlayer2.Size = new System.Drawing.Size(80, 80);
            this.picPlayer2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPlayer2.TabIndex = 11;
            this.picPlayer2.TabStop = false;
            this.picPlayer2.Visible = false;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(100, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(220, 24);
            this.lblTitle.TabIndex = 12;
            this.lblTitle.Text = "Classmates RPG Battle";
            // 
            // BattleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 400);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.picPlayer2);
            this.Controls.Add(this.picPlayer1);
            this.Controls.Add(this.lblHealth2);
            this.Controls.Add(this.lblHealth1);
            this.Controls.Add(this.txtBattleLog);
            this.Controls.Add(this.btnStartBattle);
            this.Controls.Add(this.cboPlayer2Class);
            this.Controls.Add(this.txtPlayer2Name);
            this.Controls.Add(this.lblPlayer2);
            this.Controls.Add(this.cboPlayer1Class);
            this.Controls.Add(this.txtPlayer1Name);
            this.Controls.Add(this.lblPlayer1);
            this.Name = "BattleForm";
            this.Text = "Classmates RPG Battle";
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPlayer2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlayer1;
        private System.Windows.Forms.TextBox txtPlayer1Name;
        private System.Windows.Forms.ComboBox cboPlayer1Class;
        private System.Windows.Forms.Label lblPlayer2;
        private System.Windows.Forms.TextBox txtPlayer2Name;
        private System.Windows.Forms.ComboBox cboPlayer2Class;
        private System.Windows.Forms.Button btnStartBattle;
        private System.Windows.Forms.TextBox txtBattleLog;
        private System.Windows.Forms.Label lblHealth1;
        private System.Windows.Forms.Label lblHealth2;
        private System.Windows.Forms.PictureBox picPlayer1;
        private System.Windows.Forms.PictureBox picPlayer2;
        private System.Windows.Forms.Label lblTitle;
    }
}