﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ClassmatesRPG
{
    public partial class BattleForm : Form
    {
        private ClassFighter player1;
        private ClassFighter player2;
        private Random random = new Random();

        public BattleForm()
        {
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            // Set form properties
            this.BackColor = Color.LightGray;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Load images from file path
            try
            {
                string imagePath = Path.Combine(Application.StartupPath, "Images", "default_character.png");
                picPlayer1.Image = Image.FromFile(imagePath);
                picPlayer2.Image = Image.FromFile(imagePath);
            }
            catch
            {
                // Fallback to system icons
                picPlayer1.Image = SystemIcons.Exclamation.ToBitmap();
                picPlayer2.Image = SystemIcons.Question.ToBitmap();
            }
        }

        private void btnStartBattle_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                if (string.IsNullOrWhiteSpace(txtPlayer1Name.Text) || string.IsNullOrWhiteSpace(txtPlayer2Name.Text))
                {
                    throw new Exception("Both players must have names!");
                }

                if (cboPlayer1Class.SelectedItem == null || cboPlayer2Class.SelectedItem == null)
                {
                    throw new Exception("Both players must select a class!");
                }

                // Create players based on selections
                player1 = CreateCharacter(txtPlayer1Name.Text, cboPlayer1Class.SelectedItem.ToString());
                player2 = CreateCharacter(txtPlayer2Name.Text, cboPlayer2Class.SelectedItem.ToString());

                // Update UI
                UpdateHealthDisplay();
                txtBattleLog.Clear();
                txtBattleLog.AppendText($"Battle between {player1.Name} and {player2.Name} begins!\r\n");

                // Start battle
                StartBattle();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private ClassFighter CreateCharacter(string name, string className)
        {
            switch (className)
            {
                case "QuizMaster Quincy":
                    return new QuizMasterQuincy(name);
                case "Debugger Dana":
                    return new DebuggerDana(name);
                case "CodeCrusher Carlos":
                    return new CodeCrusherCarlos(name);
                default:
                    throw new Exception("Invalid character class selected!");
            }
        }

        private void StartBattle()
        {
            btnStartBattle.Enabled = false;
            txtPlayer1Name.Enabled = false;
            txtPlayer2Name.Enabled = false;
            cboPlayer1Class.Enabled = false;
            cboPlayer2Class.Enabled = false;

            // Battle loop
            while (player1.Health > 0 && player2.Health > 0)
            {
                // Player 1 attacks
                int damage = player1.Attack();
                player2.TakeDamage(damage);
                txtBattleLog.AppendText($"{player1.Name} attacks {player2.Name} for {damage} damage!\r\n");
                UpdateHealthDisplay();

                if (player2.Health <= 0) break;

                // Player 2 attacks
                damage = player2.Attack();
                player1.TakeDamage(damage);
                txtBattleLog.AppendText($"{player2.Name} attacks {player1.Name} for {damage} damage!\r\n");
                UpdateHealthDisplay();

                // Small delay for readability
                Application.DoEvents();
                System.Threading.Thread.Sleep(500);
            }

            // Determine winner
            string winner = player1.Health > 0 ? player1.Name : player2.Name;
            txtBattleLog.AppendText($"\r\n{winner} wins the battle!\r\n");
            MessageBox.Show($"{winner} is victorious!", "Battle Over", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            // Reset UI for new battle
            btnStartBattle.Enabled = true;
            txtPlayer1Name.Enabled = true;
            txtPlayer2Name.Enabled = true;
            cboPlayer1Class.Enabled = true;
            cboPlayer2Class.Enabled = true;
        }

        private void UpdateHealthDisplay()
        {
            lblHealth1.Text = $"Health: {player1.Health}/{player1.MaxHealth}";
            lblHealth2.Text = $"Health: {player2.Health}/{player2.MaxHealth}";

            // Visual feedback when health is low
            if (player1.Health < player1.MaxHealth * 0.3)
                lblHealth1.ForeColor = Color.Red;
            else
                lblHealth1.ForeColor = SystemColors.ControlText;

            if (player2.Health < player2.MaxHealth * 0.3)
                lblHealth2.ForeColor = Color.Red;
            else
                lblHealth2.ForeColor = SystemColors.ControlText;
        }
    }

    public abstract class ClassFighter
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int MaxHealth { get; protected set; }

        public abstract int Attack();

        public void TakeDamage(int damage)
        {
            Health -= damage;
            if (Health < 0) Health = 0;
        }
    }

    public class QuizMasterQuincy : ClassFighter
    {
        private Random random = new Random();

        public QuizMasterQuincy(string name)
        {
            Name = name;
            MaxHealth = 120;
            Health = MaxHealth;
        }

        public override int Attack()
        {
            // QuizMaster has a chance for critical hits (30% chance)
            int baseDamage = random.Next(10, 20);
            return random.Next(0, 100) < 30 ? baseDamage * 2 : baseDamage;
        }
    }

    public class DebuggerDana : ClassFighter
    {
        private Random random = new Random();

        public DebuggerDana(string name)
        {
            Name = name;
            MaxHealth = 90;
            Health = MaxHealth;
        }

        public override int Attack()
        {
            // Debugger has consistent but lower damage with chance to stun (skip opponent's turn)
            return random.Next(8, 15);
        }
    }

    public class CodeCrusherCarlos : ClassFighter
    {
        private Random random = new Random();

        public CodeCrusherCarlos(string name)
        {
            Name = name;
            MaxHealth = 150;
            Health = MaxHealth;
        }

        public override int Attack()
        {
            // CodeCrusher has high variance damage
            return random.Next(5, 30);
        }
    }
}