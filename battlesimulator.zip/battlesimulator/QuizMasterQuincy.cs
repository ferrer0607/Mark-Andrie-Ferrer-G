﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battlesimulator
{
    class QuizMasterQuincy
    {
    }
}


namespace ClassBattleGame
{
    public class QuizMasterQuincy : ClassFighter
    {
        private static Random rand = new Random();

        public QuizMasterQuincy(string name) : base(name, 120) { }

        public override int Attack()
        {
            return rand.Next(5, 26); // Quincy deals 5–25 damage
        }
    }
}
