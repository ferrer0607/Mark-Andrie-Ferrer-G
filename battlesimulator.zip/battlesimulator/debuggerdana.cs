﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battlesimulator
{
    class debuggerdana
    {
    }
}


namespace ClassBattleGame
{
    public class DebuggerDana : ClassFighter
    {
        private static Random rand = new Random();

        public DebuggerDana(string name) : base(name, 100) { }

        public override int Attack()
        {
            return rand.Next(10, 21); // Dana deals 10–20 damage
        }
    }
}
